package com.ltp.gradesubmission.security.manager;

public class CustomAuthenticationManager {
    
}
