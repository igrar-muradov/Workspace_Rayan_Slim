package com.ltp.gradesubmission;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradeSubmissionApplicationTests {

	@Test
	void contextLoads() {
	}

}
